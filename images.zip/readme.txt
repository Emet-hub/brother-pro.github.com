    color: #fff;
    btn-top: linear-gradient(to right,#fe8464 0%,#fe6e9a 50%,#fe8464 100%);
    background-size: 200%;
    
    btn-color: #fe7856;
    btn-border: 2px solid #fe7856;

#fe7860;
            #506cf0;
#a7c0cd;
or,
#00A9D8;
#0D9EDF;
#259B9A;
or,
#3FD2C7;
#99DDFF;
#00458B;
or,
#1F3044;
#FB9039;
#646C79;
or,
#001730;
#4AD7D1;
#FE4A49;
or,
#AD4328;
#B65741;

